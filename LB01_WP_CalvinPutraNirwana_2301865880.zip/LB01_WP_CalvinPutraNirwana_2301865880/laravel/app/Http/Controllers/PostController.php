<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Details;
use App\Models\Books;
use App\Models\Category;
use \Illuminate\Support\Facades\DB;

class PostController extends Controller
{
    public function home(Request $request)
    {
        $data = Books::with('detail', 'category');
        if (isset($request->category)) {
            $data->where('category_id', $request->category);
        }
        $data = $data->get();

        return view('home', [
            'data' => $data,
        ]);
    }
    public function detail($id)
    {
        $data = Books::with('detail', 'category')->find($id);
        return view('/fictiondetail', [
            'data' => $data
        ]);
    }
}
