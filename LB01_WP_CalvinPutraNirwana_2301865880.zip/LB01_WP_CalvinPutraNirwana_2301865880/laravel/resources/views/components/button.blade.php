<div class="container">
    <div class="d-flex float-end mb-2">
        <a href="">
            <button type="button" class="btn btn-light ">
                << Previous</button>
        </a>
        <a href="">
            <button type="button" class="btn btn-light ">
                Next >></button>
        </a>
    </div>
</div>
