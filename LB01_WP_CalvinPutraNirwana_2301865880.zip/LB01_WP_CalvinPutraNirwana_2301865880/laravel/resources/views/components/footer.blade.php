<div class="container bg-primary bg-gradient">
    <div class="row">
        <p class="text-center text-white my-1">
            &copy; Happy Book Store
        </p>
    </div>
</div>
