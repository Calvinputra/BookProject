@php
$category = \App\Models\Category::all();
@endphp
{{-- Navbar --}}
<div class="container bg-primary bg-gradient">
    <div class="row">
        <div>
            <p class="text-center my-5 fs-1 text-white">
                Happy Book Store
            </p>
        </div>
    </div>
</div>

<nav class=" container navbar navbar-expand-lg navbar-light bg-light">
    <div class="container ">
        <div class="collapse navbar-collapse d-flex justify-content-center" id="navbarNavDropdown">
            <ul class="navbar-nav ">
                <li class="nav-item">
                    <a style="font-weight:bold" class="nav-link active me-3 text-primary" aria-current="page"
                        href="/">Home</a>
                </li>
                <li class="nav-item dropdown">
                    <a style="font-weight:bold" class="nav-link dropdown-toggle me-3 text-primary" href="#"
                        id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Category
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        @foreach ($category as $categories)
                            <li><a class="dropdown-item" style="font-weight:bold"
                                    href="/?category={{ $categories->id }}">{{ $categories->category }}</a></li>
                        @endforeach
                    </ul>
                </li>
                <li class="nav-item">
                    <a style="font-weight:bold" class="nav-link me-3 text-primary" href="/contact">Contact</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
