@php
$category = \App\Models\Category::all();
@endphp
<h4 class="bg-warning py-2 ps-3">
    Category
</h4>
<div class="list-unstyled">
    @foreach ($category as $categories)
        <li><a class="dropdown-item text-primary bg-light mb-2" style="font-weight:bold"
                href="/?category={{ $categories->id }}">{{ $categories->category }}</a>
        </li>
    @endforeach
</div>
