@extends('navtemplate')

@section('container')

@endsection
<x-header />

<div class="container">
    <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8 mt-4">
            <div class="row container bg-primary bg-gradient ms-1">
                <div>
                    <p class="text-center my-2 fs-1 text-white">
                        Book Detail
                    </p>
                </div>
            </div>
            <div class="container">
                <div>
                    <div class="pt-2">
                        <h5 class="pt-2">
                            Title : {{ $data->title }}
                        </h5>
                        <h5 class="pt-2">
                            Author : {{ $data->detail->author }}
                        </h5>
                        <h5 class="pt-2">
                            Publisher : {{ $data->detail->publisher }}
                        </h5>
                        <h5 class="pt-2">
                            Year : {{ $data->detail->year }}
                        </h5>
                        <h5 class="pt-2">
                            Description :
                            {{ $data->detail->description }}
                        </h5>
                    </div>
                </div>
            </div>

        </div>
        <div class="col-sm-2 mt-4">
            <x-category />
        </div>
    </div>
</div>


<x-footer />
