@extends('navtemplate')

@section('container')

@endsection

<x-header />

<div class="container">
    <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8 mt-4">
            <div class="row container bg-primary bg-gradient ms-1">
                <div>
                    <p class="text-center my-2 fs-1 text-white">
                        Book List
                    </p>
                </div>
            </div>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">Title</th>
                        <th scope="col">Author</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($data as $book)
                        <tr>
                            <td scope="row" data-toggle="tooltip" data-placement="bottom" title="Book Detail">
                                <a href=" /fictiondetail/{{ $book->id }} "
                                    class="text-decoration-none text-black">{{ $book->title }}
                                </a>
                            </td>
                            <td>
                                {{ $book->detail->author }}
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            <x-button />
        </div>
        <div class="col-sm-2 mt-4">
            <x-category />
        </div>
    </div>
</div>
<x-footer />
