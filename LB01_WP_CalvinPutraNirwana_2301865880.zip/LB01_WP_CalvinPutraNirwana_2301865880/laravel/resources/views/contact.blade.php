@extends('navtemplate')

@section('container')

@endsection
<x-header />

<div class="container">
    <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8 mt-4">
            <div class="row container bg-primary bg-gradient ms-1">
                <div>
                    <p class="text-center my-2 fs-1 text-white">
                        Contact
                    </p>
                </div>
            </div>
            <div class="container">
                <div class="pt-2">
                    <h3 class="pt-2">
                        Store Address :
                    </h3>
                    <h5 class="pt-2">
                        Jalan Pembangunan Baru Raya,
                    </h5>
                    <h5 class="pt-2">
                        Kompleks Pertokoan EmeraldBlok iii/12
                    </h5>
                    <h5 class="pt-2">
                        Bintaro, Tangerang Selatan
                    </h5>
                    <h5 class="pt-2">
                        Indonesia
                    </h5>

                    <h3 class="pt-3">
                        Open Daily :
                    </h3>
                    <h5 class="pt-2">
                        08.00 - 20.00
                    </h5>
                    <h3 class="pt-3">
                        Contact :
                    </h3>
                    <h5 class="pt-2">
                        Phone : 021-0889481561
                    </h5>
                    <h5 class="pt-2">
                        Email : happybookstore@happy.com
                    </h5>
                </div>
            </div>
        </div>
        <div class="col-sm-2 mt-4">
            <x-category />
        </div>
    </div>
</div>


<x-footer />
