<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DetailsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('details')->insert([[
            'book_id' => '1',
            'author' => 'Veronica Roth',
            'publisher' => 'HarperCollins',
            'year'=> '2011',
            'description'=> 'Kisah novel ini berlangsung di kota Chicago masa depan usai perang nuklir yang menghancurkan dunia'
        ],[
            'book_id' => '2',
            'author' => 'Veronica Roth',
            'publisher' => 'HarperCollins',
            'year'=> '2012',
            'description'=> 'Four dan Tris yang di kendalikan oleh Eric dan Jeanine, keduanya menginginkan divergents mati dengan segala cara'
        ],[
            'book_id' => '3',
            'author' => 'Veronica Roth',
            'publisher' => 'HarperCollins',
            'year'=> '2013',
            'description'=> 'Allegiant merupakan buku terakhir trilogi yang menandai puncak dari semua fakta yang ada.'
        ],[
            'book_id' => '4',
            'author' => 'Andrea Hirata',
            'publisher' => 'Bentang Pustaka',
            'year'=> '2005',
            'description'=> 'Laskar Pelangi merupakan buku pertama dari Tetralogi Laskar Pelangi'
        ],[
            'book_id' => '5',
            'author' => 'Habiburrahman El Shirazy',
            'publisher' => 'Republika',
            'year'=> '2004',
            'description'=> 'Ayat Ayat Cinta juga merupakan pelopor karya sastra Islami yang sedang dalam masa kebangkitannya dewasa ini.'
        ],[
            'book_id' => '6',
            'author' => 'Carl Sagan',
            'publisher' => 'Random House',
            'year'=> '1980',
            'description'=> 'satu buku sains paling laris sepanjang sejarah'
        ],[
            'book_id' => '7',
            'author' => 'Sergei Lukyanenko',
            'publisher' => 'AST',
            'year'=> '2001',
            'description'=> 'Humans have left their cradle, colonized numerous extrasolar planets'
        ],[
            'book_id' => '8',
            'author' => 'Stephen Hawking',
            'publisher' => 'Bantam Dell Publishing Group',
            'year'=> '1998',
            'description'=> ' berbagai hal dalam kosmologi, termasuk Ledakan Besar, lubang hitam, dan kerucut cahaya, untuk pembaca awam.'
        ],[
            'book_id' => '9',
            'author' => 'Eric Dubay',
            'publisher' => 'Bumi Media',
            'year'=> '2016',
            'description'=> 'Selama ini kita meyakini bahwa bentuk bumi adalah bulat'
        ],[
            'book_id' => '10',
            'author' => 'Richard Dawkins',
            'publisher' => 'Oxford University Press',
            'year'=> '1976',
            'description'=> 'Suatu organisme ini diharapkan untuk berevolusi memaksimalkan kesesuaian yang inklusif'
        ],[
            'book_id' => '11',
            'author' => 'Jubilee Enterprise',
            'publisher' => 'Elex Media Komputindo',
            'year'=> '2020',
            'description'=> 'anda bisa meningkatkan kemampuan dan kecanggihan MS Excel melalui bahasa pemrograman VBA '
        ],[
            'book_id' => '12',
            'author' => 'Jason',
            'publisher' => 'Gramedia',
            'year'=> '2008',
            'description'=> 'anda bisa meingkatkan Audio & Visual'
        ],[
            'book_id' => '13',
            'author' => 'Ragil',
            'publisher' => 'Gramedia',
            'year'=> '2006',
            'description'=> 'Tingkatkan Officemu'
        ],[
            'book_id' => '14',
            'author' => 'Jonathan Chang',
            'publisher' => 'Oxford University Press',
            'year'=> '2016',
            'description'=> 'Anda dapat dengan mudah membuat aplikasi'
        ],[
            'book_id' => '15',
            'author' => 'Calvin Putra',
            'publisher' => 'Harvard University Press',
            'year'=> '2018',
            'description'=> 'Cara mudah memakai Visual Studio'
        ]]);
    }
}
