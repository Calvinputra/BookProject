<?php

namespace Database\Seeders;

use App\Models\Books;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BooksSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('books')->insert([[
            'category_id' => '1',
            'title' => 'Divergent'
        ],[
            'category_id' => '1',
            'title' => 'Insurgent'
        ],[
            'category_id' => '1',
            'title' => 'Allegiant'
        ],[
            'category_id' => '1',
            'title' => 'Laskah Pelangi'
        ],[
            'category_id' => '1',
            'title' => 'Ayat-Ayat Cinta'    
        ],[
            'category_id' => '2',
            'title' => 'Cosmos'   
        ],[
            'category_id' => '2',
            'title' => 'Genome'    
        ],[
            'category_id' => '2',
            'title' => 'A Brief History Of Time'   
        ],[
            'category_id' => '2',
            'title' => 'Flat Earth'     
        ],[
            'category_id' => '2',
            'title' => 'The Selfish gene'      
        ],[
            'category_id' => '3',
            'title' => 'Excel'     
        ],[
            'category_id' => '3',
            'title' => 'Audio & Visual '    
        ],[
            'category_id' => '3',
            'title' => 'Office'   
        ],[
            'category_id' => '3',
            'title' => 'Android'   
        ],[
            'category_id' => '3',
            'title' => 'Visual Studio'  
        ]]);
    }
}
