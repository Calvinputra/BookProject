<?php
$category = \App\Models\Category::all();
?>
<h4 class="bg-warning py-2 ps-3">
    Category
</h4>
<div class="list-unstyled">
    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a class="dropdown-item text-primary bg-light mb-2" style="font-weight:bold"
                href="/?category=<?php echo e($categories->id); ?>"><?php echo e($categories->category); ?></a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH D:\Kuliah\Semester 5 Sekarang\UTS\LB01_WP_CalvinPutraNirwana_2301865880\laravel\resources\views/components/category.blade.php ENDPATH**/ ?>