<?php $__env->startSection('container'); ?>

<?php $__env->stopSection(); ?>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.header','data' => []]); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<div class="container">
    <div class="row">
        <div class="col-sm-2"></div>
        <div class="col-sm-8 mt-4">
            <div class="row container bg-primary bg-gradient ms-1">
                <div>
                    <p class="text-center my-2 fs-1 text-white">
                        Book List
                    </p>
                </div>
            </div>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">Title</th>
                        <th scope="col">Author</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row" data-toggle="tooltip" data-placement="bottom" title="Book Detail"> <a
                                href="/fictiondetail" class="text-decoration-none text-black">Fiction</a></th>
                        <td>Someone Who Cares</td>
                    </tr>
                    <tr>
                        <th scope="row" data-toggle="tooltip" data-placement="bottom" title="Book Detail"> <a
                                href="/fictiondetail" class="text-decoration-none text-black">Fiction 2</a></th>
                        <td>Someone Who Cares</td>
                    </tr>
                    <tr>
                        <th scope="row" data-toggle="tooltip" data-placement="bottom" title="Book Detail"> <a
                                href="/fictiondetail" class="text-decoration-none text-black">Fiction 3</a></th>
                        <td>Someone Who Cares</td>
                    </tr>
                    <tr>
                        <th scope="row" data-toggle="tooltip" data-placement="bottom" title="Book Detail"> <a
                                href="/fictiondetail" class="text-decoration-none text-black" href="">Science</a></th>
                        <td>Someone Who Cares</td>
                    </tr>
                    <tr>
                        <th scope="row" data-toggle="tooltip" data-placement="bottom" title="Book Detail"> <a
                                href="/fictiondetail" class="text-decoration-none text-black" href="">Science 2</a></th>
                        <td>Someone Who Cares</td>
                    </tr>
                </tbody>
            </table>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => []]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>
        <div class="col-sm-2 mt-4">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.category','data' => []]); ?>
<?php $component->withName('category'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>
    </div>
</div>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.footer','data' => []]); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<?php echo $__env->make('navtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Semester 5 Sekarang\UTS\LB01_WP_CalvinPutraNirwana_2301865880\laravel\resources\views/Home.blade.php ENDPATH**/ ?>