<div class="container bg-primary bg-gradient">
    <div class="row">
        <p class="text-center text-white my-1">
            &copy; Happy Book Store
        </p>
    </div>
</div>
<?php /**PATH D:\Kuliah\Semester 5 Sekarang\UTS\LB01_WP_CalvinPutraNirwana_2301865880\laravel\resources\views/components/footer.blade.php ENDPATH**/ ?>