
<div class="container bg-primary bg-gradient">
    <div class="row">
        <div>
            <p class="text-center my-5 fs-1 text-white">
                Happy Book Store
            </p>
        </div>
    </div>
</div>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container ">
        <div class="collapse navbar-collapse d-flex justify-content-center" id="navbarNavDropdown">
            <ul class="navbar-nav ">
                <li class="nav-item">
                    <a style="font-weight:bold" class="nav-link active me-3 text-primary" aria-current="page"
                        href="/">Home</a>
                </li>
                <li class="nav-item dropdown">
                    <a style="font-weight:bold" class="nav-link dropdown-toggle me-3 text-primary" href="#"
                        id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Category
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <li><a class="dropdown-item" style="font-weight:bold" href="/fiction">Fiction</a></li>
                        <li><a class="dropdown-item" style="font-weight:bold" href="#">Science</a></li>
                        <li><a class="dropdown-item" style="font-weight:bold" href="#">Computer</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a style="font-weight:bold" class="nav-link me-3 text-primary" href="/contact">Contact</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH D:\Kuliah\Semester 5 Sekarang\UTS\LB01_WP_CalvinPutraNirwana_2301865880\laravel\resources\views/components/Header.blade.php ENDPATH**/ ?>