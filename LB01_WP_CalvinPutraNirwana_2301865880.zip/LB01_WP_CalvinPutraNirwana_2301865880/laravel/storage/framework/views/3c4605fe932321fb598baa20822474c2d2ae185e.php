<div class="container">
    <div class="d-flex float-end mb-2">
        <a href="">
            <button type="button" class="btn btn-light ">
                << Previous</button>
        </a>
        <a href="">
            <button type="button" class="btn btn-light ">
                Next >></button>
        </a>
    </div>
</div>
<?php /**PATH D:\Kuliah\Semester 5 Sekarang\UTS\LB01_WP_CalvinPutraNirwana_2301865880\laravel\resources\views/components/button.blade.php ENDPATH**/ ?>